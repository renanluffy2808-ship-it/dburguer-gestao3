package br.com.dburger.gestao

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.view.View
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.webkit.WebViewAssetLoader

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView

    companion object {
        // URL oficial da aplicação na nuvem (equivalência 100% idêntica ao Preview)
        const val CLOUD_APP_URL = "https://ais-pre-7efzph6crbemm74j5vlixo-848988395362.us-east1.run.app"
        const val LOCAL_BUNDLE_URL = "https://appassets.androidplatform.net/assets/www/index.html"
    }

    private fun isNetworkAvailable(): Boolean {
        return try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val network = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (e: Exception) {
            false
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Tema Dark profissional nas barras de status e navegação do celular
        window.statusBarColor = Color.parseColor("#09090B")
        window.navigationBarColor = Color.parseColor("#18181B")

        // AssetLoader oficial do AndroidX para servir assets locais embutidos sem restrição de CORS
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                allowFileAccess = true
                allowContentAccess = true
                allowFileAccessFromFileURLs = true
                allowUniversalAccessFromFileURLs = true

                // Configurações vitais para fidelidade mobile idêntica ao preview:
                // Desativa zoom de desktop para respeitar 1:1 o viewport mobile e densidade de tela
                useWideViewPort = false
                loadWithOverviewMode = false
                textZoom = 100 // Impede que o tamanho de fonte do sistema Android distorça o layout

                cacheMode = WebSettings.LOAD_DEFAULT
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                mediaPlaybackRequiresUserGesture = false
                displayZoomControls = false
                builtInZoomControls = false
                setSupportZoom(false)
            }
            setBackgroundColor(Color.parseColor("#09090B"))
            scrollBarStyle = View.SCROLLBARS_INSIDE_OVERLAY
            isVerticalScrollBarEnabled = false

            webChromeClient = object : WebChromeClient() {
                override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                    android.util.Log.d("DBurgerApp", "${consoleMessage?.message()} [linha ${consoleMessage?.lineNumber()}]")
                    return true
                }
            }

            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView,
                    request: WebResourceRequest
                ): WebResourceResponse? {
                    return assetLoader.shouldInterceptRequest(request.url)
                }

                override fun onReceivedError(
                    view: WebView,
                    request: WebResourceRequest,
                    error: WebResourceError
                ) {
                    super.onReceivedError(view, request, error)
                    // Se falhar ao carregar a URL da nuvem, faz fallback automático imediato para o bundle local embutido
                    if (request.isForMainFrame && !request.url.toString().startsWith("https://appassets.androidplatform.net")) {
                        view.post {
                            view.loadUrl(LOCAL_BUNDLE_URL)
                        }
                    }
                }
            }
        }

        setContentView(webView)

        // Trata o botão Voltar físico/gestual do celular para navegar nas abas e fechar modais
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        // Inicialização inteligente: conecta à nuvem se conectado, ou usa bundle local embutido se offline
        if (isNetworkAvailable()) {
            webView.loadUrl(CLOUD_APP_URL)
        } else {
            webView.loadUrl(LOCAL_BUNDLE_URL)
        }
    }
}
